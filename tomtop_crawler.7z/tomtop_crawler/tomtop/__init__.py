import logging.config


def init_log():
    print("initing log")
    logging.config.fileConfig('logger_config.ini')


class TomTopLogging:
    def __init__(self):
        logging.config.fileConfig('logger_config.ini')
