import pandas as pd

from db_helper import build_connection
from helper import load_config, get_execl_file_name


class ExportErrors:
    def __init__(self, product_table_name: str = "products_1"):
        self.config = load_config()
        self.errot_table = f"{product_table_name}_error"

    def export(self):
        with build_connection(self.config.database_name) as conn:
            query = f"select * from {self.errot_table}"
            df_error = pd.read_sql(query, conn, index_col=None)
            file_path = get_execl_file_name("errors", file_type="csv")
            df_error.to_csv(file_path, index=None)


if __name__ == '__main__':
    e = ExportErrors()
    e.export()
