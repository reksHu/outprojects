from typing import List

import pandas as pd

from db_helper import TableNames, build_connection, get_database_full_name
from tomtop.helper import open_driver, load_config


def retrieval_links() -> List:
    """
    获取一级导航和二级导航
    """
    # driver = get_driver()
    links_result = []
    url = "https://www.tomtop.com/"
    # self.driver.get(url)
    with open_driver(is_page_load_strategy=False) as driver:
        driver.get(url)
        top_nav_lis = driver.find_elements_by_xpath("//ul[@id='c_nav']/li")
        if top_nav_lis is not None and len(top_nav_lis) > 0:
            print("top_nav_lis has data：", len(top_nav_lis))
            top_nav_lis = top_nav_lis[1:]  # 取消第一個
            for li in top_nav_lis:
                nav_first_link = li.find_element_by_xpath("./a[@class='nav_first']")
                nav_first_url = nav_first_link.get_attribute("href")
                nav_first_title = nav_first_link.text.strip()
                # print(f"nav_first_title:{nav_first_title}; nav_first_url:{nav_first_url}")

                # get sub_nav
                sub_divs = li.find_elements_by_xpath("./div/div")
                for sub_div in sub_divs:
                    sub_link_eles = sub_div.find_elements_by_xpath("./dl/dt/a")
                    for sub_link in sub_link_eles:
                        # link = sub_link.find_elements_by_xpath("./a")
                        sub_url = sub_link.get_attribute("href")
                        sub_title = sub_link.get_attribute("title")
                        item = [nav_first_title, nav_first_url, sub_title, sub_url]
                        links_result.append(item)
                        # print(f"sub_title:{sub_title}, sub_url:{sub_url}")
                        print(item)
    return links_result


def save_links_to_db(links_result: List):
    """
    将一二级导航保存到数据库中
    """
    config = load_config()
    # print(config.database_name)
    links_columns = ["first_nav_title", "first_nav_url", "sub_nav_title", "sub_nav_url"]
    links_df = pd.DataFrame(links_result, columns=links_columns)
    print(links_df.head(30))
    database = get_database_full_name(config.database_name)
    with build_connection(database) as conn:
        links_df.to_sql(TableNames.NAV_TABLE_NAME.value, conn, if_exists="replace")


if __name__ == '__main__':
    links_result: List = retrieval_links()
    save_links_to_db(links_result)

# retrivel_links()

# driver = get_driver()
# url = "https://www.tomtop.com/cameras-camcorders-10029/"
# driver.get(url)
#
# lis = driver.find_elements_by_xpath("//ul[contains(@class,'categoryProductList')]/li")
# for li in lis:
#     prices_ele = li.find_element_by_xpath("./div[@class='product_box']/div[@class='priceWarp']")
#     print(prices_ele.text)
