from typing import List

import pandas as pd

from db_helper import build_connection
from helper import load_config, get_execl_file_name
from tomtop.logs.logger_helper import TomtopLogger


class ExportResult(TomtopLogger):
    def __init__(self, table_name: str):
        super(ExportResult, self).__init__()
        self.config = load_config()
        self.table_name = table_name
        self.execel_columns = ["name(en-gb)", "manufacturer", "image_name", "price",
                               "seo_keyword", "description(en-gb)", "meta_title(en-gb)",
                               "meta_description(en-gb)"]

    def read_data_and_export(self):
        products_list = []
        specials_list = []
        product_options_list = []
        addition_images_list = []
        temp_images_list = []
        with build_connection(self.config.database_name) as conn:
            # order:  product_title, brand_text, regular_price, warehouse, plugs, colors, images, description,url,product_desc
            query = f"SELECT * from {self.table_name}"
            cousor = conn.execute(query)
            for product_id, c in enumerate(cousor, start=1001):
                name = c[0]
                seo_keyword = name
                images_str = str(c[7])
                temp_images_list.append([product_id,images_str])
                # TODO will replace with meta name="twitter:title" value
                meta_title = name
                manufacturer = c[1]
                image_names = "" if c[7] == "" else "\n".join(images_str.split(","))
                price = c[3]
                plugs = c[5]
                colors = c[6]
                meta_desc = c[8]
                product_desc = c[-1]
                products_list.append(
                    [product_id, manufacturer, image_names, price, seo_keyword, product_desc, meta_title, meta_desc])
                specials_list.append([product_id, price])
                product_options_list.append([product_id, colors])

        self.export_products_excel(products_list)
        self.export_specials_excel(specials_list)
        self.export_product_options_excel(product_options_list)
        addition_images_list = self.handle_images(temp_images_list)
        self.export_addition_iamges(addition_images_list)

    def handle_images(self, temp_images_list: str):
        product_image_list = []
        for item in temp_images_list:
            product_id, images_str = item
            images_array = images_str.split(",")
            for image in images_array:
                product_image_list.append([product_id,image])
        return product_image_list

    def export_products_excel(self, products_list: List):
        columns = ["product_id", "manufacturer", "image_name", "price",
                   "seo_keyword", "description(en-gb)", "meta_title(en-gb)",
                   "meta_description(en-gb)"]
        pd_products = pd.DataFrame(products_list, columns=columns, index=None)
        file_path = get_execl_file_name("products")
        pd_products.to_excel(file_path, index=False, engine='xlsxwriter')

    def export_specials_excel(self, specials_list: List):
        coloums = ["product_id", "price"]
        df = pd.DataFrame(specials_list, columns=coloums, index=None)
        file_path = get_execl_file_name("Specials")
        df.to_excel(file_path, index=False, engine='xlsxwriter')

    def export_product_options_excel(self, product_options_list: List):
        coloums = ["product_id", "option"]
        df = pd.DataFrame(product_options_list, columns=coloums, index=None)
        file_path = get_execl_file_name("ProductOptions")
        df.to_excel(file_path, index=False, engine='xlsxwriter')

    def export_addition_iamges(self, addition_images_list: List):
        coloums = ["product_id", "image"]
        df = pd.DataFrame(addition_images_list, columns=coloums, index=None)
        print(df.head(5))
        file_path = get_execl_file_name("AdditionalImages")
        df.to_excel(file_path,index=False, engine='xlsxwriter')


if __name__ == '__main__':
    e = ExportResult("products_1")
    e.read_data_and_export()
