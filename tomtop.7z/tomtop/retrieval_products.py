import logging
import traceback
from sqlite3 import Connection
from typing import List

import pandas as pd
from selenium.common.exceptions import TimeoutException, NoSuchElementException, StaleElementReferenceException

# import tomtop
from db_helper import build_connection, get_database_full_name
from helper import load_config, open_driver, is_element_visible
from tomtop.logs.logger_helper import TomtopLogger
from tomtop.modules.configuration import DBConfig


class RetrievalProducts(TomtopLogger):
    """
    根据商品url地址，解析出商品详细信息
    """

    def __init__(self, product_url_list: List, table_name: str):
        super(RetrievalProducts, self).__init__()
        self.logger = logging.getLogger(__name__)
        self.config = load_config()
        self.product_urls = product_url_list
        self.error_list = []
        self.table_name = table_name
        self.error_table = f"{table_name}_error"
        self.product_infos = []
        self._create_table()

    def parse_product(self):
        with open_driver() as driver:
            # self.logger.info(f"抓取商品页面:{driver.current_url}")
            database_path = get_database_full_name(self.config.database_name)
            with build_connection(database_path) as conn:
                for index, product_url in enumerate(self.product_urls):
                    try:
                        product_info = []
                        self.logger.info(f"抓取商品页面:{product_url}")
                        driver.get(product_url)
                        # self.logger.info(f"opened url:{product_url}")
                        images_list = []

                        if is_element_visible(driver, "//ul[contains(@class,'productSmallmove')]"):
                            images_li_eles = driver.find_elements_by_xpath(
                                "//ul[contains(@class,'productSmallmove')]/li")
                            for image_ele in images_li_eles:
                                image_link = image_ele.find_element_by_xpath("./a")
                                image_url = image_link.get_attribute("href")
                                images_list.append(image_url)

                        self.logger.info(f"images length:{len(images_list)} for url: {product_url}")

                        if is_element_visible(driver, "//div[contains(@class,'showInformation')]"):

                            info_ele = driver.find_element_by_xpath("//div[contains(@class,'showInformation')]")
                            product_title = info_ele.find_element_by_xpath("./h1/span").text
                            self.logger.info(f"product_title:{product_title}")

                            brand_ele = info_ele.find_elements_by_xpath(
                                "./div[@class='shareWarp']/span[contains(@class,'brand')]/a/em")
                            brand_text = ""
                            if brand_ele is not None and len(brand_ele) > 0:
                                brand_text = brand_ele[0].text

                            regular_price_ele = info_ele.find_elements_by_xpath(
                                "./div[@class='saleWarp']/p[@class='lineBlock']/span")
                            regular_price = ""
                            if regular_price_ele is not None and len(regular_price_ele) > 0:
                                regular_price = regular_price_ele[0].text

                            price_warp_ele = info_ele.find_element_by_xpath(
                                "./div[@class='priceWarp']/div/p/span[@class='symbolLab']")
                            price_unit = price_warp_ele.text
                            detail_price = info_ele.find_element_by_xpath("//p[@id='detailPrice']").text
                            price = f"{price_unit}{detail_price}"

                            warehouse_li = info_ele.find_element_by_xpath(
                                "./div[contains(@class,'shippingFrom')]/div/ul[@id='wearhouseList']/li")
                            warehouse = warehouse_li.get_attribute("title")

                            # print(product_title)
                            # print(brand_text, price_unit, price, warehouse)
                            colors_list = []
                            plugs = []
                            color_plug_eles = info_ele.find_elements_by_xpath("./div[contains(@class,'color')]")
                            if len(color_plug_eles) == 2:
                                plug_li_eles = info_ele.find_elements_by_xpath(
                                    "./div[contains(@class,'color')][first()]/div[@class='item_box']/ul/li")
                                for plug_ele in plug_li_eles:
                                    plug = plug_ele.get_attribute("title")
                                    plugs.append(plug)
                                colors_eles = info_ele.find_elements_by_xpath(
                                    "./div[contains(@class,'color')][2]/div[@class='item_box']/ul/li")

                                for color_ele in colors_eles:
                                    color = color_ele.get_attribute("title")
                                    colors_list.append(color)
                            else:
                                colors_eles = info_ele.find_elements_by_xpath(
                                    "./div[contains(@class,'color')][last()]/div[@class='item_box']/ul/li")
                                for color_ele in colors_eles:
                                    color = color_ele.get_attribute("title")
                                    colors_list.append(color)
                            product_desc = ""
                            # if is_element_visible(driver,"//div[id='description']"):
                            product_desc_ele = driver.find_elements_by_xpath("//div[@id='description']")
                            for desc_ele in product_desc_ele:
                                product_desc = desc_ele.text

                            # description_meta = ""
                            # if is_element_visible(driver,"//meta[@name='description']"):
                            description_meta_ele = driver.find_element_by_xpath("//meta[@name='description']")
                            description_meta = description_meta_ele.get_attribute("content")
                            self.logger.info(f"description_meta:{description_meta[:50]}")

                            # print("product_desc,",product_desc)

                            product_info = [product_title, brand_text, regular_price, price, warehouse,
                                            ",".join(plugs), ",".join(colors_list), ",".join(images_list),
                                            description_meta, product_url, product_desc]

                            self.logger.info(f"_parse_product_information done")
                            # DowloadImages(images_list).dowload_images()
                            self.product_infos.append(product_info)

                        # self.product_infos.append(product_info)
                        self.save_on_db(conn, product_info)
                    except TimeoutException as e:
                        self.logger.error(f"parse_product TimeoutException:{product_url}")
                    except NoSuchElementException as e:
                        self.error_list.append([product_url, f"NoSuchElementException:{str(e.msg)}"])
                        self.logger.exception(e)
                    except StaleElementReferenceException:
                        self.error_list.append([product_url, f"StaleElementReferenceException occured"])
                        driver.refresh()
                    finally:
                        self._save_error_on_db(conn)
                        conn.commit()

    def parse_product_1(self):
        try:
            # with open_driver() as driver:
            #     for index, product_url in enumerate(self.product_urls):
            #         with build_connection(self.config.database_name) as conn:
            #             try:
            #                 product_info = self._parse_product_information(product_url,driver)
            #                 self.save_on_db(conn, product_info)
            #             except TimeoutException as e:
            #                 self.logger.error(f"parse_product TimeoutException:{product_url}")
            #             except NoSuchElementException as e:
            #                 self.error_list.append([product_url, f"NoSuchElementException:{str(e.msg)}"])
            #                 self.logger.exception(e)
            #             finally:
            #                 self._save_error_on_db(conn)
            #                 conn.commit()
            database_path = get_database_full_name(self.config.database_name)
            with build_connection(database_path) as conn:
                for index, product_url in enumerate(self.product_urls):
                    try:
                        product_info = self._parse_product_information(product_url)
                        # self.product_infos.append(product_info)
                        self.save_on_db(conn, product_info)
                    except TimeoutException as e:
                        self.logger.error(f"parse_product TimeoutException:{product_url}")
                    except NoSuchElementException as e:
                        self.error_list.append([product_url, f"NoSuchElementException:{str(e.msg)}"])
                        self.logger.exception(e)
                    finally:
                        self._save_error_on_db(conn)
                        conn.commit()

        except Exception:
            self.logger.error(traceback.format_exc())

        # return product_infos

    def _parse_product_information(self, product_url: str) -> List:
        try:
            self.logger.info(f"_parse_product_information at {product_url}")
            with open_driver() as driver:
                product_info = []
                self.logger.info(f"opening url:{product_url}")
                driver.get(product_url)
                self.logger.info(f"opened url:{product_url}")
                images_list = []

                if is_element_visible(driver, "//ul[contains(@class,'productSmallmove')]"):
                    images_li_eles = driver.find_elements_by_xpath("//ul[contains(@class,'productSmallmove')]/li")
                    for image_ele in images_li_eles:
                        image_link = image_ele.find_element_by_xpath("./a")
                        image_url = image_link.get_attribute("href")
                        images_list.append(image_url)

                self.logger.info(f"images length:{len(images_list)} for url: {product_url}")

                if is_element_visible(driver, "//div[contains(@class,'showInformation')]"):

                    info_ele = driver.find_element_by_xpath("//div[contains(@class,'showInformation')]")
                    product_title = info_ele.find_element_by_xpath("./h1/span").text
                    self.logger.info(f"product_title:{product_title}")

                    brand_ele = info_ele.find_elements_by_xpath(
                        "./div[@class='shareWarp']/span[contains(@class,'brand')]/a/em")
                    brand_text = ""
                    if brand_ele is not None and len(brand_ele) > 0:
                        brand_text = brand_ele[0].text

                    regular_price_ele = info_ele.find_elements_by_xpath(
                        "./div[@class='saleWarp']/p[@class='lineBlock']/span")
                    regular_price = ""
                    if regular_price_ele is not None and len(regular_price_ele) > 0:
                        regular_price = regular_price_ele[0].text

                    price_warp_ele = info_ele.find_element_by_xpath(
                        "./div[@class='priceWarp']/div/p/span[@class='symbolLab']")
                    price_unit = price_warp_ele.text
                    detail_price = info_ele.find_element_by_xpath("//p[@id='detailPrice']").text
                    price = f"{price_unit}{detail_price}"

                    warehouse_li = info_ele.find_element_by_xpath(
                        "./div[contains(@class,'shippingFrom')]/div/ul[@id='wearhouseList']/li")
                    warehouse = warehouse_li.get_attribute("title")

                    # print(product_title)
                    # print(brand_text, price_unit, price, warehouse)
                    colors_list = []
                    plugs = []
                    color_plug_eles = info_ele.find_elements_by_xpath("./div[contains(@class,'color')]")
                    if len(color_plug_eles) == 2:
                        plug_li_eles = info_ele.find_elements_by_xpath(
                            "./div[contains(@class,'color')][first()]/div[@class='item_box']/ul/li")
                        for plug_ele in plug_li_eles:
                            plug = plug_ele.get_attribute("title")
                            plugs.append(plug)
                        colors_eles = info_ele.find_elements_by_xpath(
                            "./div[contains(@class,'color')][2]/div[@class='item_box']/ul/li")

                        for color_ele in colors_eles:
                            color = color_ele.get_attribute("title")
                            colors_list.append(color)
                    else:
                        colors_eles = info_ele.find_elements_by_xpath(
                            "./div[contains(@class,'color')][last()]/div[@class='item_box']/ul/li")
                        for color_ele in colors_eles:
                            color = color_ele.get_attribute("title")
                            colors_list.append(color)
                    product_desc = ""
                    # if is_element_visible(driver,"//div[id='description']"):
                    product_desc_ele = driver.find_elements_by_xpath("//div[@id='description']")
                    for desc_ele in product_desc_ele:
                        product_desc = desc_ele.text

                    # description_meta = ""
                    # if is_element_visible(driver,"//meta[@name='description']"):
                    description_meta_ele = driver.find_element_by_xpath("//meta[@name='description']")
                    description_meta = description_meta_ele.get_attribute("content")
                    self.logger.info(f"description_meta:{description_meta[:50]}")

                    # print("product_desc,",product_desc)

                    product_info = [product_title, brand_text, regular_price, price, warehouse,
                                    ",".join(plugs), ",".join(colors_list), ",".join(images_list),
                                    description_meta, product_url, product_desc]

                    self.logger.info(f"_parse_product_information done:{product_info[:-1]}")
                    # DowloadImages(images_list).dowload_images()
                    self.product_infos.append(product_info)
                return product_info

        except TimeoutException as e:
            self.logger.info(f"_parse_product_information TimeoutException occured at {product_url}")
            self.error_list.append([product_url, "page timeout error"])
            raise e

        except NoSuchElementException as e:
            self.logger.exception(e)
            raise e

    def save_on_db(self, conn: Connection, product_info: List):
        self.logger.info(f"saving product_info length: {len(self.product_infos)}")
        # if len(self.product_infos) % 20 == 0:
        self.logger.info(f"saving products information into database, table_name: {self.table_name}")

        columns_definition = "product_title,brand_text,regular_price,price,warehouse,plugs,colors,images,description,url, product_desc"
        value_place_holder = f",".join(
            ["?" for i in range(len(DBConfig.products_table_columns_definition) - 1)])
        insert_sql = f"insert into {self.table_name}({columns_definition}) values({value_place_holder})"
        self.logger.info(f"insert_sql:{insert_sql}")
        try:
            conn.execute(insert_sql, product_info)
            # if len(self.product_infos) % 10 == 0:
            self.logger.info("product_infos commit")
            if len(self.product_infos) % 10 == 0:
                conn.commit()
                self.logger.info(f"saved product information with count: {len(self.product_infos)}")

        except Exception as e:
            self.logger.exception(e)

    def _save_error_on_db(self, conn: Connection):
        error_df = pd.DataFrame(self.error_list, columns=["error_url", "error_desc"])
        error_df.to_sql(self.error_table, conn, if_exists="replace")

    # 创建数据库表 内部方法

    def _create_table(self):
        # [job_title, salary, company_name, location, experience, education_background, spot_num, public_date,
        #  job_detail, job_category, job_keywords, company_type, company_size, company_business_scope, url]
        columns_definition = ",".join(DBConfig.products_table_columns_definition[1:])
        create_sql = f"create table  if not exists {self.table_name}({columns_definition})"
        error_table_create = f"create table if not exists {self.error_table}({','.join(DBConfig.error_table_columns_definition)})"
        database_path = get_database_full_name(self.config.database_name)
        with build_connection(database_path) as conn:
            # 创建数据库游标
            cursor = conn.cursor()
            print(create_sql)
            print(error_table_create)
            # 执行数据库语句， 这时候数据仍然在内存中
            cursor.execute(create_sql)
            cursor.execute(error_table_create)
            # 提交数据库执行，只有提交后才能最后保存
            conn.commit()

if __name__ == '__main__':
    product_url = "https://www.tomtop.com/p-k6098-2.html"
    table_name = "products_1"
    p = RetrievalProducts([product_url,"https://www.tomtop.com/p-k13083.html"], table_name)
    p.parse_product()
