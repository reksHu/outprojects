from typing import List

import attr
# from sele_wangpu.helper import get_lib_path
from path import Path


# from helper import get_database_path

@attr.s(auto_attribs=True)
class Configuration:
    """
    配置类，用来解析config.yaml文件的，两个地方的字段名需要一致

    """
    city: List = attr.ib(default=[])
    file_location: str = attr.ib(default="")
    driver_name: str = attr.ib(default="")
    crawler_type: str = attr.ib(default="")
    database_name: str = attr.ib(default="tomtop.db")
    navigation_name: str = attr.ib(default="")

    def driver_path(self, lib_path: Path) -> Path:
        return lib_path / self.driver_name


@attr.s(auto_attribs=True)
class DBConfig:
    """
    定义数据库名字的类
    """

    # 记录错误 爬取数据 的数据表名
    error_table: str = "errors"

    # 因为解析的字段多，定义了一个内容表的 字段定义字典，方便在这里统一改数据表结构
    products_table_columns_definition = ["id integer primary key autoincrement",
                                         "product_title varchar(255)",
                                         "brand_text text",
                                         "regular_price varchar(255)",
                                         "price varchar(100)",
                                         "warehouse varchar(100)",
                                         "plugs varchar(100)",
                                         "colors varchar(200)",
                                         "images text",
                                         "description text",
                                         "url varchar(255)",
                                         "product_desc text"
                                         ]

    product_urls_columns_definition = ["id integer primary key autoincrement",
                                       "product_url varchar(255)",
                                       "nav_url varchar(255)",
                                       "unique(product_url)"
                                       ]

    error_table_columns_definition = ["id integer primary key autoincrement",
                                      "url varchar(255)",
                                      "error_msg text",
                                      "unique(url)"]
