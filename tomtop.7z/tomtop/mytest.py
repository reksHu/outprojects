# import tomtop.logger_helper
# from logger_helper import logger
# import logger_helper
# import logging.config
# from logger_helper import logger
import re

from db_helper import build_connection, TableNames, get_database_full_name
from helper import load_config
from tomtop.helper import open_driver
import pandas as pd

def save_on_db():
    config = load_config()
    product_info = []
    product_info.append(["2", "https://www.tomtop.com/p-k13634-2.html", "connection error"])
    product_info.append(["3", "https://www.tomtop.com/pXXXX.html", "error"])

    with build_connection(config.database_name) as conn:
        columns_definition = "'index',error_url,error_desc"
        insert_sql = f"insert into products_1_error({columns_definition}) values(?,?,?)"
        conn.executemany(insert_sql, product_info)
        # if len(self.product_infos) % 10 == 0:
        conn.commit()


def load_nav_links_data() -> pd.DataFrame:
    config = load_config()
    database = get_database_full_name(config.database_name)
    query = f"select sub_nav_url, first_nav_title from {TableNames.NAV_TABLE_NAME.value}"
    with build_connection(database) as conn:
        db_result_df = pd.read_sql(query, conn, columns=["sub_url"])
        # print(db_result_df)
        if config.navigation_name != "":
            # self.logger.info(f"navigation_name:{config.navigation_name}")
            result = db_result_df[db_result_df["first_nav_title"] == config.navigation_name]
            for url in result["sub_nav_url"]:
                print(url)
            # print(result["sub_nav_url"])
            return result
        print(db_result_df)
        return db_result_df
# save_on_db()
#
# if __name__ == '__main__':
#     import time
#     url = "http://wenshu.court.gov.cn/website/wenshu/181217BMTKHNT2W0/index.html?pageId=6da24549d149ad6a74b71246b0705c68&s21=%E9%98%BF%E9%87%8C%E5%B7%B4%E5%B7%B4"
#
#     with open_driver() as driver:
#         driver.get(url)
#         time.sleep(5*60*100)


if __name__ == '__main__':
    # load_nav_links_data()
    last_number = 22
    url_pattern = "(\d*.html)"
    # result = list(range(2, last_number))
    last_link_url = "/security-protection-10323/21.html"
    first_url = re.sub(url_pattern,"",last_link_url.lower())
    print(first_url)
    for index in range(2, last_number):
        paging_url = re.sub(url_pattern, f"{index}.html", last_link_url.lower())
        print(paging_url)