# import tomtop.logger_helper
# from logger_helper import logger
# import logger_helper
# import logging.config
# from logger_helper import logger
import sqlite3

import pandas as pd

from db_helper import build_connection, TableNames, get_database_full_name
from helper import load_config


def save_on_db():
    config = load_config()
    product_info = []
    product_info.append(["2", "https://www.tomtop.com/p-k13634-2.html", "connection error"])
    product_info.append(["3", "https://www.tomtop.com/pXXXX.html", "error"])

    with build_connection(config.database_name) as conn:
        columns_definition = "'index',error_url,error_desc"
        insert_sql = f"insert into products_1_error({columns_definition}) values(?,?,?)"
        conn.executemany(insert_sql, product_info)
        # if len(self.product_infos) % 10 == 0:
        conn.commit()


def load_nav_links_data() -> pd.DataFrame:
    config = load_config()
    database = get_database_full_name(config.database_name)
    query = f"select sub_nav_url, first_nav_title from {TableNames.NAV_TABLE_NAME.value}"
    with build_connection(database) as conn:
        db_result_df = pd.read_sql(query, conn, columns=["sub_url"])
        # print(db_result_df)
        if config.navigation_name != "":
            # self.logger.info(f"navigation_name:{config.navigation_name}")
            result = db_result_df[db_result_df["first_nav_title"] == config.navigation_name]
            for url in result["sub_nav_url"]:
                print(url)
            # print(result["sub_nav_url"])
            return result
        print(db_result_df)
        return db_result_df


# save_on_db()
#
# if __name__ == '__main__':
#     import time
#     url = "http://wenshu.court.gov.cn/website/wenshu/181217BMTKHNT2W0/index.html?pageId=6da24549d149ad6a74b71246b0705c68&s21=%E9%98%BF%E9%87%8C%E5%B7%B4%E5%B7%B4"
#
#     with open_driver() as driver:
#         driver.get(url)
#         time.sleep(5*60*100)

def test_insert():
    import pandas as pd
    config = load_config()
    database_path = get_database_full_name(config.database_name)
    insert_sql = f"insert into products_url_1(product_url，nav_url) values(?,?)"
    items = [
        ['https://www.tomtop.com/p-k14852.html', 'https://www.tomtop.com/p-k15641.html',
         'https://www.tomtop.com/p-k14745-1.html', 'https://www.tomtop.com/p-k15228.html',
         'https://www.tomtop.com/p-k15343b.html', 'https://www.tomtop.com/p-k15080bl.html',
         'https://www.tomtop.com/p-k5473r-1.html', 'https://www.tomtop.com/p-k15230.html',
         'https://www.tomtop.com/p-k3235.html', 'https://www.tomtop.com/p-k11320.html',
         'https://www.tomtop.com/p-k4446b.html', 'https://www.tomtop.com/p-k369db.html',
         'https://www.tomtop.com/p-k409.html', 'https://www.tomtop.com/p-k3804.html',
         'https://www.tomtop.com/p-k4925.html', 'https://www.tomtop.com/p-k2798.html',
         'https://www.tomtop.com/p-k4804.html', 'https://www.tomtop.com/p-k5342b.html',
         'https://www.tomtop.com/p-k11798-1.html', 'https://www.tomtop.com/p-k14888-l.html',
         'https://www.tomtop.com/p-k5331w.html', 'https://www.tomtop.com/p-k7026.html',
         'https://www.tomtop.com/p-k6651-1.html', 'https://www.tomtop.com/p-rm12043b.html',
         'https://www.tomtop.com/p-k4758.html', 'https://www.tomtop.com/p-k7349bl-l.html',
         'https://www.tomtop.com/p-k5464.html', 'https://www.tomtop.com/p-k5446b.html',
         'https://www.tomtop.com/p-y14262-1.html', 'https://www.tomtop.com/p-k11449.html',
         'https://www.tomtop.com/p-k3700.html', 'https://www.tomtop.com/p-k4176.html',
         'https://www.tomtop.com/p-k4950-2.html', 'https://www.tomtop.com/p-k8086.html',
         'https://www.tomtop.com/p-k4806.html', 'https://www.tomtop.com/p-k7020.html',
         'https://www.tomtop.com/p-paa2238b.html', 'https://www.tomtop.com/p-k11035.html',
         'https://www.tomtop.com/p-k3357.html', 'https://www.tomtop.com/p-k6984.html',
         'https://www.tomtop.com/p-k4447.html', 'https://www.tomtop.com/p-k1428.html',
         'https://www.tomtop.com/p-k2827b.html', 'https://www.tomtop.com/p-k7246gy.html',
         'https://www.tomtop.com/p-k5346b.html', 'https://www.tomtop.com/p-k5008.html',
         'https://www.tomtop.com/p-k4754-1.html', 'https://www.tomtop.com/p-k5130.html',
         'https://www.tomtop.com/p-k4201.html', 'https://www.tomtop.com/p-k10995.html',
         'https://www.tomtop.com/p-k6277.html', 'https://www.tomtop.com/p-k8453b-l.html',
         'https://www.tomtop.com/p-h27695b-l.html', 'https://www.tomtop.com/p-k5259.html',
         'https://www.tomtop.com/p-k6396-1.html', 'https://www.tomtop.com/p-k11097w.html',
         'https://www.tomtop.com/p-k4902b.html', 'https://www.tomtop.com/p-k3935.html',
         'https://www.tomtop.com/p-k4998-3.html', 'https://www.tomtop.com/p-k4165.html',
         'https://www.tomtop.com/p-k14852.html', 'https://www.tomtop.com/p-k15641.html',
         'https://www.tomtop.com/p-k14745-1.html', 'https://www.tomtop.com/p-k15228.html',
         'https://www.tomtop.com/p-k15343b.html', 'https://www.tomtop.com/p-k15080bl.html',
         'https://www.tomtop.com/p-k5473r-1.html', 'https://www.tomtop.com/p-k15230.html',
         'https://www.tomtop.com/p-k3235.html', 'https://www.tomtop.com/p-k11320.html',
         'https://www.tomtop.com/p-k4446b.html', 'https://www.tomtop.com/p-k369db.html',
         'https://www.tomtop.com/p-k409.html', 'https://www.tomtop.com/p-k3804.html',
         'https://www.tomtop.com/p-k4925.html', 'https://www.tomtop.com/p-k2798.html',
         'https://www.tomtop.com/p-k4804.html', 'https://www.tomtop.com/p-k5342b.html',
         'https://www.tomtop.com/p-k11798-1.html', 'https://www.tomtop.com/p-k14888-l.html',
         'https://www.tomtop.com/p-k5331w.html', 'https://www.tomtop.com/p-k7026.html',
         'https://www.tomtop.com/p-k6651-1.html', 'https://www.tomtop.com/p-rm12043b.html',
         'https://www.tomtop.com/p-k4758.html', 'https://www.tomtop.com/p-k7349bl-l.html',
         'https://www.tomtop.com/p-k5464.html', 'https://www.tomtop.com/p-k5446b.html',
         'https://www.tomtop.com/p-y14262-1.html', 'https://www.tomtop.com/p-k11449.html',
         'https://www.tomtop.com/p-k3700.html', 'https://www.tomtop.com/p-k4176.html',
         'https://www.tomtop.com/p-k4950-2.html', 'https://www.tomtop.com/p-k8086.html',
         'https://www.tomtop.com/p-k4806.html', 'https://www.tomtop.com/p-k7020.html',
         'https://www.tomtop.com/p-paa2238b.html', 'https://www.tomtop.com/p-k11035.html',
         'https://www.tomtop.com/p-k3357.html', 'https://www.tomtop.com/p-k6984.html',
         'https://www.tomtop.com/p-k4447.html', 'https://www.tomtop.com/p-k1428.html',
         'https://www.tomtop.com/p-k2827b.html', 'https://www.tomtop.com/p-k7246gy.html',
         'https://www.tomtop.com/p-k5346b.html', 'https://www.tomtop.com/p-k5008.html',
         'https://www.tomtop.com/p-k4754-1.html', 'https://www.tomtop.com/p-k5130.html',
         'https://www.tomtop.com/p-k4201.html', 'https://www.tomtop.com/p-k10995.html',
         'https://www.tomtop.com/p-k6277.html', 'https://www.tomtop.com/p-k8453b-l.html',
         'https://www.tomtop.com/p-h27695b-l.html', 'https://www.tomtop.com/p-k5259.html',
         'https://www.tomtop.com/p-k6396-1.html', 'https://www.tomtop.com/p-k11097w.html',
         'https://www.tomtop.com/p-k4902b.html', 'https://www.tomtop.com/p-k3935.html',
         'https://www.tomtop.com/p-k4998-3.html', 'https://www.tomtop.com/p-k4165.html']
    ]
    df = pd.DataFrame(items, columns=["product_url", "nav_url"], index=None)

    print(df.head(4))
    # try:
    #     with build_connection(database_path) as conn:
    #         df.to_sql("products_url_1", conn, index=False, if_exists="append")
    #         # conn.executemany(insert_sql, items)
    #     # conn.commit()
    #     # df.to_sql(self.prod_urls_table, conn, if_exists="append")
    # except sqlite3.IntegrityError as e:
    #     print("UNIQ error happend")


if __name__ == '__main__':
    # load_nav_links_data()
    last_number = 22
    # url_pattern = "(\d*.html)"
    # # result = list(range(2, last_number))
    # last_link_url = "/security-protection-10323/21.html"
    # first_url = re.sub(url_pattern,"",last_link_url.lower())
    # print(first_url)
    # for index in range(2, last_number):
    #     paging_url = re.sub(url_pattern, f"{index}.html", last_link_url.lower())
    #     print(paging_url)

    test_insert()
