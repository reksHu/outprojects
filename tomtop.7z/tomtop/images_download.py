import logging
import logging.config
import threading
from typing import List, Optional

import requests
import urllib3
from requests.exceptions import ConnectTimeout, ReadTimeout, ConnectionError

from helper import get_folder_path, load_config
from tomtop.db_helper import build_connection, get_database_full_name
from tomtop.logs.logger_helper import TomtopLogger

urllib3.disable_warnings()

__all__ = [
    "DowloadImages"
]


class DownloadImagesThreading(threading.Thread):
    def __init__(self, image_url: str, logger: logging):
        super(DownloadImagesThreading, self).__init__()
        self.image_url = image_url
        self.logger = logger

    def run(self) -> None:
        header = {
            "User-Agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36"
        }
        try:
            image_name = self.image_url.split("/")[-1]
            image_folder = get_folder_path("images")
            image_file_path = image_folder / image_name
            if image_file_path.exists():
                self.logger.info(f"图片{image_name}已经存在，不再下载")
                return
            self.logger.info(f"正在下载图片 {image_name}")
            res = requests.get(url=self.image_url, headers=header, timeout=30, verify=False)
            image_file_path.write_bytes(res.content)
        except (ConnectTimeout, ReadTimeout, ConnectionError) as e:
            self.logger.error(f"{self.image_url} 下载失败, 请求超时")
        except Exception as e:
            self.logger.error("图片下载抛出异常")
            self.logger.exception(e)


class DowloadImages(TomtopLogger):
    def __init__(self, image_list: Optional[List] = None):
        super(DowloadImages, self).__init__()
        self.logger = logging.getLogger(__name__)
        self.image_list = image_list

    def dowload_images(self, table_name: str):
        config = load_config()
        database_path = get_database_full_name(config.database_name)
        with build_connection(database_path) as conn:
            query = f"select images from {table_name} WHERE images!=''"
            cursor = conn.execute(query)
            for row in cursor:
                row_images = row[0].split(",")
                print(row_images)
                if len(row_images) > 0:
                    self.image_list = row_images
                    self._run_dowload()

    def _run_dowload(self):
        try:
            self.logger.info(f"一共下载 {len(self.image_list)} 个图片")
            threads = [DownloadImagesThreading(image_url, self.logger) for image_url in self.image_list]
            for t in threads:
                t.start()

            for t in threads:
                t.join()
        except Exception:
            pass

# if __name__ == '__main__':
#     images = "https://img.tttcdn.com/product/xy/2000/2000/p/gu1/K/1/K12076-1/K12076-1-1-ef8a-q1V2.jpg,https://img.tttcdn.com/product/xy/2000/2000/p/gu1/K/1/K12076-1/K12076-1-1-ef8a-3FnB.jpg,https://img.tttcdn.com/product/xy/2000/2000/p/gu1/K/1/K12076-1/K12076-1-1-ef8a-Kj4B.jpg,https://img.tttcdn.com/product/xy/2000/2000/p/gu1/K/1/K12076-1/K12076-1-1-ef8a-Wws3.jpg,https://img.tttcdn.com/product/xy/2000/2000/p/gu1/K/1/K12076-1/K12076-1-1-ef8a-iajx.jpg,https://img.tttcdn.com/product/xy/2000/2000/p/gu1/K/1/K12076-1/K12076-1-1-ef8a-OtnE.jpg,https://img.tttcdn.com/product/xy/2000/2000/p/gu1/K/1/K12076-1/K12076-1-1-ef8a-vhKn.jpg,https://img.tttcdn.com/product/xy/2000/2000/p/gu1/K/1/K12076-1/K12076-1-1-ef8a-4XM6.jpg,https://img.tttcdn.com/product/xy/2000/2000/p/gu1/K/1/K12076-1/K12076-1-1-ef8a-UWtu.jpg,https://img.tttcdn.com/product/xy/2000/2000/p/gu1/K/1/K12076-1/K12076-1-1-ef8a-BQZY.jpg,https://img.tttcdn.com/product/xy/2000/2000/p/gu1/K/1/K12076-1/K12076-1-1-ef8a-RIDf.jpg,https://img.tttcdn.com/product/xy/2000/2000/p/gu1/K/1/K12076-1/K12076-1-1-ef8a-Pony.jpg,https://img.tttcdn.com/product/xy/2000/2000/p/gu1/K/1/K12076-1/K12076-1-1-ef8a-9w9K.jpg"
#     images_list = images.split(",")
#     d = DowloadImages(images_list)
#     d.dowload_images()
