import os
from contextlib import contextmanager
from datetime import datetime
from typing import Optional

import selenium.webdriver.support.expected_conditions as EC
import selenium.webdriver.support.ui as ui
import yaml
from path import Path
from selenium import webdriver
from selenium.common.exceptions import TimeoutException
from selenium.webdriver import ChromeOptions
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium.webdriver.remote.webdriver import WebDriver

from tomtop.modules.configuration import Configuration


def get_driver(configuration: Optional[Configuration] = None,
               is_page_load_strategy=True) -> WebDriver:
    """
    获取chrome 内核配置信息，模拟成浏览器并加速浏览器访问网页速度
    :param configuration:
    :return:
    """
    if configuration is None:
        configuration = load_config()
    chrome_options = Options()
    # chrome_options.add_argument('--headless')
    chrome_options.add_argument('--disable-gpu')
    # chrome_options.add_argument('lang=zh_CN.UTF-8')  # 设置中文
    # 设置图片不加载
    prefs = {"profile.managed_default_content_settings.images": 2}

    chrome_options.add_argument('--incognito')
    chrome_options.add_argument('--log-level=3')

    chrome_options.add_experimental_option("prefs", prefs)
    chrome_options.add_experimental_option('excludeSwitches', ['enable-automation'])
    # 设置成用户自己的数据目录
    # p = r'C:\Users\Boss\AppData\Local\Google\Chrome\User Data'
    # chrome_options.add_argument("--user-data-dir="+p)

    # 携带Cookie  通过使用Chrome选项保持所有登录在会话之间持久user-data-dir
    # chrome_options.add_argument("user-data-dir=selenium")

    chrome_options.add_argument(
        'user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36')

    option = ChromeOptions()
    option.add_experimental_option('excludeSwitches', ['enable-automation'])

    if is_page_load_strategy:
        # 不等html加载完成就开始解析
        caps = DesiredCapabilities().CHROME
        caps["pageLoadStrategy"] = "none"

        chrome = webdriver.Chrome(configuration.driver_path(get_lib_path()),
                                  chrome_options=chrome_options,
                                  desired_capabilities=caps, options=option)
    else:
        chrome = webdriver.Chrome(configuration.driver_path(get_lib_path()),
                                  chrome_options=chrome_options,
                                  options=option)

    chrome.set_page_load_timeout(300)
    # chrome = webdriver.Chrome(configuration.driver_path)
    chrome.implicitly_wait(5)
    return chrome


def is_element_visible(driver, locator, timeout=20):
    try:
        ui.WebDriverWait(driver, timeout).until(EC.visibility_of_element_located((By.XPATH, locator)))
        return True
    except TimeoutException:
        return False


def get_today_str() -> str:
    now = datetime.now()
    now_str = datetime.strftime(now, '%Y%m%d_%H%M%S')
    # now_str = datetime.strftime(now, '%Y%m%d')
    return now_str


def get_urls_file_name(menu_name: str) -> Path:
    temp_path = get_temp_path()
    name = temp_path / f"{menu_name}_urls_{get_today_str()}.csv"
    return name


def get_execl_file_name(file_name: str, file_type: str = 'xlsx') -> Path:
    file_location = get_execel_folder_path()
    name = file_location / f"{file_name}_{get_today_str()}.{file_type}"
    return name


def load_config() -> Configuration:
    """
    加载 config.yaml配置文件数据，存放如 Configuration 类中
    :return: Configuration 类
    """
    config_path = "config.yaml"
    # 将yaml文件存入二进制流中
    content = Path(config_path).read_text(encoding="utf-8")
    # 使用yaml模块解析文件，解析规则为所有内容， c_loader 为 字典类型
    c_loader = yaml.load(content, yaml.FullLoader)
    # 将字典类型动态转换成 类，方便强类型使用
    configuration = Configuration(**c_loader["configuration"])
    # 返回 configuration 类
    return configuration


def get_temp_path() -> Path:
    root = get_package_root_path()
    temp_path = Path(root) / "temp"
    temp_path.makedirs_p()
    return temp_path


def get_folder_path(folder_name: str) -> Path:
    root = get_package_root_path()
    folder = Path(root) / folder_name
    if not folder.exists():
        folder.makedirs_p()
    return folder


def get_package_root_path():
    return os.path.dirname(__file__)


def get_execel_folder_path():
    root = get_package_root_path()
    temp_path = Path(root) / "excels"
    temp_path.makedirs_p()
    return temp_path


def get_lib_path() -> Path:
    return Path(get_package_root_path()) / "libs"


@contextmanager
def open_driver(is_page_load_strategy=True) -> WebDriver:
    driver = None
    try:
        driver = get_driver(is_page_load_strategy=is_page_load_strategy)
        # driver.get(url)
        yield driver
    except Exception as e:
        raise e
    finally:
        if driver is not None:
            driver.close()
