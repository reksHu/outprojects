import logging
import os
import re
import sqlite3
from typing import List, Optional

import pandas as pd
from selenium.common.exceptions import TimeoutException, StaleElementReferenceException
from selenium.webdriver.remote.webdriver import WebDriver

from db_helper import get_database_full_name, build_connection, TableNames
from helper import load_config, open_driver
from modules.configuration import DBConfig
from tomtop.logs.logger_helper import TomtopLogger


# tomtop.init_log()

# logger = logging.getLogger(__name__)


def load_nav_links_data() -> pd.DataFrame:
    config = load_config()
    database = get_database_full_name(config.database_name)
    query = f"select sub_nav_url, first_nav_title from {TableNames.NAV_TABLE_NAME.value}"
    with build_connection(database) as conn:
        db_result_df = pd.read_sql(query, conn, columns=["sub_url"])
        # print(db_result_df)
        if config.navigation_name != "":
            # self.logger.info(f"navigation_name:{config.navigation_name}")
            return db_result_df[db_result_df["first_nav_title"] == config.navigation_name]
        return db_result_df


class RetrievalProductsNavigation(TomtopLogger):
    """
    根据二级导航获取所有商品的链接地址
    """

    def __init__(self, prod_urls_table: str):
        super(RetrievalProductsNavigation, self).__init__()
        self.logger = logging.getLogger(__name__)
        self.prod_urls_table = prod_urls_table
        self.error_table = f"{self.prod_urls_table}_error"
        self.config = load_config()
        self.product_links = []
        self.logger.info(f"PID: {os.getpid()}")
        self._create_table()

    def parse_products_navs(self, page_url: str):
        self.logger.info(f"paging parse:{page_url}")
        database_item = []
        error_list = []
        try:
            with open_driver(is_page_load_strategy=False) as driver:
                driver.get(page_url)
                next_pages = self.handle_next_page(driver)

                # product_list_eles = driver.find_elements_by_xpath("//ul[contains(@class,'lbBox')]/li")
                first_page_links = self.get_products_link(driver)
                if len(first_page_links) > 0:
                    for p in first_page_links:
                        if p not in self.product_links:
                            database_item.append([p, page_url])
                            self.product_links.append(p)

                for next_page_url in next_pages:
                    try:
                        paging_products = self.get_products_link(driver, next_page_url)
                        for p in paging_products:
                            if p not in self.product_links:
                                database_item.append([p, page_url])
                                self.product_links.append(p)
                    except StaleElementReferenceException:
                        driver.refresh()

            self.save_products_link_on_db(database_item)
        except TimeoutException:
            error_msg = "TimeoutException occured at parse_products_navs"
            self.logger.error(f"{error_msg}, url: {page_url}")
            error_list.append([page_url, error_msg])
            self._save_error_on_db(error_list)
        except StaleElementReferenceException:
            driver.refresh()

    def save_products_link_on_db(self, data_result: List):
        if len(data_result) > 0:
            # df = pd.DataFrame(data_result)
            database_path = get_database_full_name(self.config.database_name)
            self.logger.info(f"database_path:{database_path}")
            print(data_result[10:])
            df = pd.DataFrame(data_result, columns=["product_url", "nav_url"], index=None)
            # insert_sql = f"insert into {self.prod_urls_table}(product_url，nav_url) values(?,?)"
            # print(insert_sql)
            # print(data_result[:10])
            try:
                with build_connection(database_path) as conn:
                    df.to_sql(self.prod_urls_table, conn, index=False, if_exists="append")

            except sqlite3.IntegrityError as e:
                self.logger.info("UNIQ error happend")

    def get_products_link(self, driver: WebDriver, page_url: Optional[str] = None):
        if page_url is not None:
            self.logger.info(f"get_products_link from url:{page_url}")
            driver.get(page_url)
        links = []
        product_list_eles = driver.find_elements_by_xpath("//ul[contains(@class,'categoryProductList')]/li")
        for product_ele in product_list_eles:
            a_ele = product_ele.find_element_by_xpath("./div[@class='product_box']/div[@class='productImg']/a")
            link = a_ele.get_attribute("href")
            if link in self.product_links:
                self.logger.info(f"******* existing in product_links:{link}")
            else:
                self.logger.info(f"get_products_link:{link}")
            links.append(link)
        return links

    def handle_next_page(self, driver: WebDriver) -> List:
        paging_url_list = []
        next_page_links = driver.find_elements_by_xpath("//ul[contains(@class,'pagingWarp')]/li/a[@rel='next']")
        page_numbers_dic = {}
        paging_url_list.append(driver.current_url)
        for link_ele in next_page_links:
            page_num: str = link_ele.text
            if page_num.isdigit():
                page_numbers_dic[(int(page_num))] = link_ele.get_attribute("href")

        if len(page_numbers_dic.keys()) > 0:
            page_nums = sorted(set(page_numbers_dic.keys()))
            last_number = page_nums[-1]
            url_pattern = "(\d*.html)"
            self.logger.info(f"next_page_links:{next_page_links}")
            print(f"next_page_links:{len(next_page_links)}")
            last_link_url = page_numbers_dic.get(last_number, "")
            for index in range(2, last_number + 1):
                paging_url = re.sub(url_pattern, f"{index}.html", last_link_url.lower())
                if paging_url:
                    paging_url_list.append(paging_url)
        else:
            self.logger.info(f"{paging_url_list} 没有分页数据")

        self.logger.info(f"paging_url_list:{paging_url_list}")
        return paging_url_list

    def _save_error_on_db(self, error_list: List):
        database_path = get_database_full_name(self.config.database_name)
        with build_connection(database_path) as conn:
            error_df = pd.DataFrame(error_list, columns=["error_url", "error_desc"])
            error_df.to_sql(self.error_table, conn, if_exists="append")

    def _create_table(self):
        columns_definition = ",".join(DBConfig.product_urls_columns_definition)
        create_sql = f"create table if not exists {self.prod_urls_table}({columns_definition})"
        database_path = get_database_full_name(self.config.database_name)
        with build_connection(database_path) as conn:
            cursor = conn.cursor()
            cursor.execute(create_sql)
            # 提交数据库执行，只有提交后才能最后保存
            conn.commit()


#
if __name__ == '__main__':
    # result = load_nav_links_data()
    prod_urls_table = "products_url_1"
    r = RetrievalProductsNavigation(prod_urls_table)
    url = "https://www.tomtop.com/car-electronics-11048/"
    r.parse_products_navs(url)
    print("final result:", r.product_links)
    print(len(r.product_links))
    print(len(set(r.product_links)))
