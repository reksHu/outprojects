import logging.config


class TomtopLogger:
    def __init__(self):
        logging.config.fileConfig("logger_config.ini")
