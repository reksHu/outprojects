import functools
import logging.config

logging.config.fileConfig('logger_config.ini')


def logger(func):
    @functools.wraps(func)
    def wapper(*args, **kwargs):
        print("abc")
        return func(*args, **kwargs)

    return wapper
