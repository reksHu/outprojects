import enum
import sqlite3
import traceback
from contextlib import contextmanager
from sqlite3 import Connection
from typing import List
import attr
from path import Path

from helper import get_package_root_path


@contextmanager
def build_connection(database_name: str) -> Connection:
    """
    建立数据库连接方法
    :param database_name: 数据库名字
    :return:
    """
    connection = None
    try:
        connection = sqlite3.connect(database_name)
        yield connection
    except Exception as e:
        print(traceback.format_exc())
        raise e
    finally:
        if connection is not None:
            connection.commit()
            connection.close()


def get_database_full_name(database_name: str):
    return Path(get_package_root_path()) / "databases" / database_name


class TableNames(enum.Enum):
    NAV_TABLE_NAME = "navigations"
    PROD_URL_TABLE = "product_urls"
    PROD_DATA_TABLE = "products"


